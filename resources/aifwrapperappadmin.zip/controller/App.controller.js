sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("aifwrapper.app.admin.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map